<?php include("header.php"); 

require 'database.php';



?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <link   href="../../css/bootstrap.min.css" rel="stylesheet">
    <script src="../../js/bootstrap.min.js"></script>    
</head>
<body>
	<div class="container">
		<h2>Добре дошъл <?php echo $_SESSION['user_name']; ?> !</h2>
		<?php
		$pdo = Database::connect();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		
		
		$sql="SELECT speciality_name_long,speciality_id FROM specialities order by speciality_name_long"; 		
		echo "<select name=subject value=''>Име на специалност</option>";
		foreach ($pdo->query($sql) as $row){
		echo "<option value=$row[speciality_id]>$row[speciality_name_long]</option>"; 		
		}
		echo "</select>";
		foreach ($pdo->query($sql) as $row){
		if($row['speciality_id']==10){
		echo "<option value=$row[speciality_id] selected>$row[speciality_name_long]</option>"; 
		}else{
		echo "<option value=$row[speciality_id]>$row[speciality_name_long]</option>"; 
		}
		}
		echo "</select>";
		
		
		$sql="SELECT course_name,course_id FROM courses order by course_id"; 
		echo "<select name=course value=''>Име на Курс</option>";
		foreach ($pdo->query($sql) as $row){
		echo "<option value=$row[course_id]>$row[course_name]</option>"; 		
		}
		echo "</select>";
		foreach ($pdo->query($sql) as $row){
		if($row['course_id']==10){
		echo "<option value=$row[course_id] selected>$row[course_name]</option>"; 
		}else{
		echo "<option value=$row[course_id]>$row[course_name]</option>"; 
		}
		}
		echo "</select>";


		 ?>
	
</body>
</html>
